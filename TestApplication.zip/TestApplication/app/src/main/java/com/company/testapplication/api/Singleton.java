package com.company.testapplication.api;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;

public class Singleton {
    private static Singleton mInstane;
    private RequestQueue requestQueue;
    private static Context mCTx;
    private ImageLoader imageLoader;


    public Singleton(Context context) {
        mCTx=context;
        this.requestQueue =requestQueue;

    }

    public Singleton(Context context, RequestQueue requestQueue) {
        mCTx=context;
        this.requestQueue =requestQueue;

    }


    private RequestQueue getRequestQueue(){
        if(requestQueue==null){
            requestQueue= Volley.newRequestQueue(mCTx.getApplicationContext());
        }
        return requestQueue;
    }

    public static synchronized Singleton getmInstane(Context context){
        if(mInstane==null){
            mInstane=new Singleton(context);
        }
        return mInstane;
    }

    public<T> void addToRequestQue(Request<T> request ){
        getRequestQueue().add(request);
    }

    public void addRequestQueue(RequestQueue request ){
        this.requestQueue =request;
    }
}
