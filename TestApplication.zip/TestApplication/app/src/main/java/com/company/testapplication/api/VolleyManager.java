package com.company.testapplication.api;

import android.app.Dialog;
import android.content.Context;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class VolleyManager {
    private StringRequest mStringRequest;
    private JsonObjectRequest mJsonObjectRequest;
    private Map<String, String> headers = new HashMap<String, String>();

    public void volley_get(Context context, String url, final ApiCallBack apiCallback) {


        // 2 创建StringRequest对象
        mStringRequest = new StringRequest(url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        apiCallback.onSuccess(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                apiCallback.onError(error);
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {

                headers.put("Accept".trim(), "application/json".trim());
                headers.put("Content-Type".trim(), "application/json; charset=UTF-8".trim());
                return headers;
            }
        };
        // 3 将StringRequest添加到RequestQueue
        mStringRequest.setRetryPolicy(new DefaultRetryPolicy(25 * 1000, 0, 0f));
        Singleton.getmInstane(context).addToRequestQue(mStringRequest);
    }


}
