package com.company.testapplication;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    List<ApiDataVo> mData;
    Context mContext;


    public MyAdapter(Context mContext, List<ApiDataVo> mData) {
        this.mData = mData;
        this.mContext = mContext;
    }

    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.list_item, parent, false);
        return new MyViewHolder(view);
    }

    public void setData(List<ApiDataVo> mData) {
        this.mData = mData;
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.MyViewHolder holder, int position) {

        ApiDataVo apiDataVo = mData.get(position);
        holder.tvTime.setText(getDate(apiDataVo.getT(), "hh:mm:ss"));
        holder.tvQty.setText(apiDataVo.getQ());
        holder.tvPrice.setText(getPrice(apiDataVo.getP()));


        switch (apiDataVo.getColor()) {
            case -1:
                holder.tvPrice.setTextColor(mContext.getResources().getColor(R.color.red, null));
                break;
            case 0:
//                    holder.tvPrice.setTextColor(mContext.getResources().getColor(R.color.white, null));
                break;
            case 1:
                holder.tvPrice.setTextColor(mContext.getResources().getColor(R.color.green, null));
                break;

        }

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView tvTime, tvPrice, tvQty;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTime = itemView.findViewById(R.id.tv_time);
            tvPrice = itemView.findViewById(R.id.tv_price);
            tvQty = itemView.findViewById(R.id.tv_qty);

        }
    }

    public static String getDate(long milliSeconds, String dateFormat) {
        // Create a DateFormatter object for displaying date in specified format.
        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);

        // Create a calendar object that will convert the date and time value in milliseconds to date.
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return formatter.format(calendar.getTime());
    }

    public static String getPrice(String price) {
        NumberFormat formatter = new DecimalFormat("#,###.##");
        double myNumber = Double.parseDouble(price);
        String formattedNumber = formatter.format(myNumber);
        return formattedNumber;
    }


}
