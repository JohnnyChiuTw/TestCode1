package com.company.testapplication.api;

import com.android.volley.VolleyError;

public interface ApiCallBack {
    void onSuccess(String respond);
    void onError(VolleyError error);
}
