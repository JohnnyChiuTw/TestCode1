package com.company.testapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.android.volley.VolleyError;
import com.company.testapplication.api.ApiCallBack;
import com.company.testapplication.api.ApiPath;
import com.company.testapplication.api.JsonHelper;
import com.company.testapplication.api.VolleyManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okio.ByteString;

public class MainActivity extends AppCompatActivity {

    final String TAG = "MainActivity";
    private OkHttpClient mClient;
    private RecyclerView recyclerView;
    private Context mContext;
    private List<ApiDataVo> mData;
    MyAdapter myAdapter;
    int L = 0;

    private final class MyWebSocketListener extends WebSocketListener {
        private static final int CLOSE_STATUS = 1000;

        @Override
        public void onOpen(WebSocket webSocket, Response response) {
            webSocket.send("What's up ?");
            webSocket.send(ByteString.decodeHex("abcd"));
            webSocket.close(CLOSE_STATUS, "Socket Closed !!");
        }

        @Override
        public void onMessage(WebSocket webSocket, String message) {
            Log.e(TAG, "Receive Message: " + message);
        }

        @Override
        public void onMessage(WebSocket webSocket, ByteString bytes) {
            Log.e(TAG, "Receive Bytes : " + bytes.hex());
        }

        @Override
        public void onClosing(WebSocket webSocket, int code, String reason) {
            webSocket.close(CLOSE_STATUS, null);
            Log.e(TAG, "Closing Socket : " + code + " / " + reason);
        }

        @Override
        public void onFailure(WebSocket webSocket, Throwable throwable, Response response) {
            Log.e(TAG, "Error : " + throwable.getMessage());
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mContext = this;
        mClient = new OkHttpClient();
        findViews();


    }


    private void findViews() {
        recyclerView = findViewById(R.id.recyclerView);
        long currentTime = Calendar.getInstance().getTimeInMillis();
        Log.d(TAG, currentTime + "!!!");
        mData = new ArrayList<>();
        myAdapter = new MyAdapter(mContext, mData);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(mContext, 1);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setAdapter(myAdapter);

        postReadApiData("symbol=BTCUSDT");

    }

    private void getData() {
        Request request = new Request.Builder().url("wss://stream.yshyqxx.com/ws/btcusdt@aggTrade").build();
        MyWebSocketListener listener = new MyWebSocketListener();
        WebSocket webSocket = mClient.newWebSocket(request, listener);
        mClient.dispatcher().executorService().shutdown();
    }


    private void postReadApiData(String id) {

        new VolleyManager().volley_get(mContext, ApiPath.getData + id, new ApiCallBack() {

            @Override
            public void onSuccess(String respond) {
                try {
                    JSONArray jsonArray = new JSONArray(respond);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        ApiDataVo apiDataVo = JsonHelper.fromJson(jsonObject.toString(), ApiDataVo.class);
                        mData.add(apiDataVo);
                    }


                    Collections.reverse(mData);
                    if (mData.size() >= 40) {
                        L = 40;
                    } else {
                        L = mData.size();
                    }
                    List<ApiDataVo> newList = new ArrayList<>(mData.subList(0, L));
                    newList = setTextColor(newList);
                    myAdapter.setData(newList);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onError(VolleyError error) {

            }
        });

    }

    private List<ApiDataVo> setTextColor(List<ApiDataVo> mData) {
        int nowColor = 0;
        for (int position = 1; position < mData.size(); position++) {

            int compare = compareDouble(mData.get(position).getP().trim(), mData.get(position - 1).getP().trim());
            Log.d(TAG, position + "," + compare + "," + mData.get(position).getP().trim() + "-" + mData.get(position - 1).getP().trim());
            if (compare == 0) {
                mData.get(position - 1).setColor(nowColor);
            } else {

                nowColor = compare;
                mData.get(position - 1).setColor(compare);
            }


        }

        return mData;
    }

    private int compareDouble(String s1, String s2) {
        double d1 = Double.parseDouble(s1);
        double d2 = Double.parseDouble(s2);
        if (d1 > d2) {
            return -1;
        } else if (d1 < d2) {
            return 1;
        } else {
            return 0;
        }
    }

}