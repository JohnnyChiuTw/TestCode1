package com.company.testapplication.api;

import android.content.Context;
import android.content.res.AssetManager;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class JsonHelper {

    private static Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public final static <T> T fromJson(String json, Class<T> classOfT) {
        return GSON.fromJson(json, (Type) classOfT);
    }

    public final static <T> T fromJson(String json, Type type) {
        return GSON.fromJson(json,  type);
    }
}
