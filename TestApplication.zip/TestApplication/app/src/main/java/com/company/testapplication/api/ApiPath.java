package com.company.testapplication.api;

public class ApiPath {


    private static final String DOMAIN = "https://api.yshyqxx.com";
    private static final String SLASH = "/";


    /**
     * #1 home 首頁溫度
     */
    public static String getData = new StringBuilder().append(DOMAIN)
            .append(SLASH)
            .append("api/v1/aggTrades?")
            .toString();



}
